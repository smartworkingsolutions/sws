<?php
/**
 * The template for displaying all single page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package SWS
 */

get_header();

	get_template_part( 'template-parts/content', 'single' );

get_footer();
