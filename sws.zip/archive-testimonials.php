<?php
/**
 * The template for displaying Testimonials Archive page.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package SWS
 */

get_header();

get_template_part( 'template-parts/content', 'testimonials' );

get_footer();
