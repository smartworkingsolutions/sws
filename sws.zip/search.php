<?php
/**
 * The template for displaying Search results.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package SWS
 */

get_header();

get_template_part( 'template-parts/content', 'profiles' );

get_footer();
